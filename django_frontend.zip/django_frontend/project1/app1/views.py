from django.shortcuts import render
from .models import User, Create
from django.http import HttpResponse,request
from django.contrib.auth.hashers import make_password
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth import logout as logout_auth
from django.contrib.auth.models import User
from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError
from django.shortcuts import redirect
import requests
from django.shortcuts import render
from django.http import JsonResponse, HttpResponse
import json


FLASK_API_BASE = "http://localhost:5000/api"

def index_view(request):
    try:
        response = requests.get(f"{FLASK_API_BASE}/events")
        response.raise_for_status()
        events = response.json().get("events", [])
        return render(request, 'index.html', {'create_list': events})
    except Exception as e:
        messages.error(request, "Failed to load events.")
        return render(request, 'index.html', {'create_list': []})



def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        if not username or not password:
            messages.error(request, "Username and password are required.")
            return render(request, 'login.html')

        payload = {
            'first_name': username,
            'password': password
        }

        try:
            response = requests.post(f"{FLASK_API_BASE}/login", json=payload, timeout=10)
            if response.status_code == 200:
                try:
                    data = response.json()
                except ValueError:
                    messages.error(request, "Invalid response from login service.")
                    return render(request, 'login.html')

                request.session['jwt_token'] = data.get("token")
                request.session['is_logged_in'] = True
                request.session['username'] = data.get("first_name", username)
                request.session['email'] = data.get("email")
                request.session['user_id'] = data.get("user_id")

                print("Session after login:", dict(request.session))  

                messages.success(request, "Login successful.")
                return redirect('index')
            else:
                try:
                    error_msg = response.json().get("error", "Login failed.")
                except ValueError:
                    error_msg = "Login failed with unexpected response."
                messages.error(request, error_msg)

        except requests.exceptions.RequestException as e:
            messages.error(request, f"Connection error: {str(e)}")
        except Exception as e:
            messages.error(request, f"Unexpected error: {str(e)}")

    return render(request, 'login.html')
def register_view(request):
    if request.method == 'POST':
        payload = {
            'first_name': request.POST.get('username'),
            'surname': request.POST.get('surname'),
            'email': request.POST.get('email'),
            'password': request.POST.get('password'),
            'contact_number': request.POST.get('contact'),
            'street_address': request.POST.get('address')
        }
        if request.POST.get('password') != request.POST.get('confirm_password'):
            messages.error(request, "Passwords do not match.")
            return redirect('register')
        try:
            response = requests.post(f"{FLASK_API_BASE}/signup", json=payload)
            if response.status_code == 201:
                messages.success(request, "User registered successfully.")
                return redirect('login')
            else:
                messages.error(request, response.json().get("error", "Registration failed."))
        except Exception as e:
            messages.error(request, "Error contacting registration service.")
    return render(request, 'register.html')

def logout_view(request):
    request.session.flush()  
    messages.success(request, "You have been logged out.")
    return redirect('index')



def profile_view(request):
    print("Session at profile view:", dict(request.session))

    user_id = request.session.get('user_id')
    token = request.session.get('jwt_token')

    if not user_id or not token:
        messages.error(request, "User not logged in.")
        return redirect('login')

    headers = {
        'Authorization': f'Bearer {token}'
    }

    try:
        response = requests.get(f"{FLASK_API_BASE}/user/{user_id}", headers=headers, timeout=10)
        if response.status_code == 200:
            try:
                user_data = response.json()
                return render(request, 'user_detail.html', {'user': user_data})
            except ValueError:
                messages.error(request, "Failed to decode user data.")
        elif response.status_code == 401:
            request.session.flush()
            messages.error(request, "Session expired. Please log in again.")
            return redirect('login')
        elif response.status_code == 403:
            messages.error(request, "Unauthorized access.")
        else:
            messages.error(request, "Unable to fetch profile.")
    except requests.exceptions.RequestException as e:
        messages.error(request, f"Error contacting user service: {str(e)}")
    except Exception as e:
        messages.error(request, f"Unexpected error: {str(e)}")

    return render(request, 'user_detail.html', {'user': {}})

def create_event(request):
    print("📥 HTTP method received:", request.method)
    
    if request.method != "POST":
        return render(request, 'event_creation.html')
        
    try:
        event_date = request.POST.get('eventDate')
        event_time = request.POST.get('eventTime')
        event_type = request.POST.get('eventType')
        game_title = request.POST.get('gameTitle')
        location = request.POST.get('eventLocation')
        
        required_fields = {
            'Event Type': event_type,
            'Game Title': game_title,
            'Location': location,
            'Date': event_date,
            'Time': event_time,
        }
        
        missing_fields = [field for field, value in required_fields.items() if not value]
        if missing_fields:
            messages.error(request, f"Missing required fields: {', '.join(missing_fields)}")
            return render(request, 'event_creation.html')
            
        formatted_datetime = f"{event_date}T{event_time}"
        
        try:
            max_participants = int(request.POST.get('max_participants', 0))
            max_spectators = int(request.POST.get('max_spectators', 0))
            ticket_price = float(request.POST.get('ticketPrice', 0))
        except ValueError:
            messages.error(request, "Invalid numeric value for participants, spectators, or ticket price")
            return render(request, 'event_creation.html')
        
        event_data = {
            'event_name': event_type,
            'event_date': formatted_datetime,
            'game_title': game_title,
            'location': location,
            'platform': request.POST.get('platform', ''),
            'max_participants': max_participants,
            'max_spectators': max_spectators,
            'ticket_price': ticket_price,
            'description': request.POST.get('eventDescription', ''),
            'user_id': request.user.id if hasattr(request, 'user') and request.user.is_authenticated else None,
        }
        
        if 'event_image' in request.FILES:
            event_image = request.FILES['event_image']
            if not event_image.name.lower().endswith(('.png', '.jpg', '.jpeg', '.gif')):
                messages.error(request, "Unsupported file format. Please upload a PNG, JPG, JPEG, or GIF image.")
                return render(request, 'event_creation.html')
                 
        
        print("📤 Sending data to API:", event_data)
        
        response = requests.post(
            f"{FLASK_API_BASE}/create-event", 
            json=event_data,
            timeout=10  
        )
        response.raise_for_status()
        
        response_data = response.json()
        event_id = response_data.get('event_id')
        
        messages.success(request, "Event created successfully!")
        
        if event_id:
            return redirect('index')
        return redirect('index')
            
    except requests.exceptions.RequestException as e:
        error_msg = f"Error communicating with the server: {str(e)}"
        print(f"❌ API Error: {error_msg}")
        messages.error(request, error_msg)
    except Exception as e:
        error_msg = f"An unexpected error occurred: {str(e)}"
        print(f"❌ Unexpected Error: {error_msg}")
        messages.error(request, error_msg)
        
    return render(request, 'event_creation.html')
def create_user(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            response = requests.post(f"{FLASK_API_BASE}/signup", json=data)
            response.raise_for_status()
            return JsonResponse(response.json(), status=201)
        except Exception as e:
            return JsonResponse({"error": str(e)}, status=400)
    return HttpResponse("Only POST allowed", status=405)
