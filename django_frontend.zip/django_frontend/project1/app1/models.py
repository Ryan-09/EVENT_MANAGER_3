from django.db import models

# Create your models here.
class User(models.Model):
    username = models.CharField(max_length=255)
    email = models.EmailField()
    password = models.CharField(max_length=255)
    
    def __str__(self):
        return self.username

class Create(models.Model):
    title = models.CharField(max_length=255)
    date=models.DateField()
    time=models.TimeField()
    location=models.CharField(max_length=255)
    price=models.IntegerField()
    image=models.ImageField(upload_to='event_images/', blank=True, null=True)   
    
    def __str__(self):
        return self.title