from . import db
from datetime import datetime
from flask_login import UserMixin
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash

class User(UserMixin, db.Model):
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(50), nullable=False)
    surname = db.Column(db.String(50), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(128))  

    def set_password(self, password):
        """Hashes the password and stores it."""
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        """Checks the hashed password."""
        return check_password_hash(self.password_hash, password)
    contact_number = db.Column(db.String(15), nullable=False)
    street_address = db.Column(db.String(255), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)

    events = db.relationship('Event', backref='creator', cascade='all, delete-orphan')
    bookings = db.relationship('Booking', backref='user', lazy=True)
    comments = db.relationship('Comment', backref='author', lazy=True)

class Event(db.Model):
    __tablename__ = 'events'

    id = db.Column(db.Integer, primary_key=True)
    game = db.Column(db.String(100), nullable=False)
    event_type = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    location = db.Column(db.String(100), nullable=False)

    participants = db.Column(db.Integer, default=0)
    max_participants = db.Column(db.Integer, nullable=False, default=0)
    spectators = db.Column(db.Integer, default=0)
    max_spectators = db.Column(db.Integer, nullable=False, default=0)

    date_time = db.Column(db.DateTime, nullable=False)
    status = db.Column(db.Enum('Open', 'Inactive', 'Sold Out', 'Cancelled', name='event_status'), nullable=False)
    image_url = db.Column(db.String(255))
    created_by_user_id = db.Column(db.Integer, db.ForeignKey('users.id',ondelete='SET NULL'), nullable=True)
    ticket_price = db.Column(db.Float, nullable=False, default=0.0)

    bookings = db.relationship('Booking', backref='event', lazy=True)
    comments = db.relationship('Comment', backref='event', lazy=True)

    def update_status(self):
        current_time = datetime.utcnow()
        
        if self.status == 'Cancelled':
            return
        if self.date_time < current_time:
            self.status = 'Inactive'
        elif self.participants >= self.max_participants:
            self.status = 'Sold Out'
        else:
            self.status = 'Open'

class Booking(db.Model):
    __tablename__ = 'bookings'

    id = db.Column(db.Integer, primary_key=True)
    quantity = db.Column(db.Integer, nullable=False)
    price = db.Column(db.Float, nullable=False)
    event_id = db.Column(db.Integer, db.ForeignKey('events.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    booking_date = db.Column(db.DateTime, default=datetime.utcnow)
    order_id = db.Column(db.String(20), unique=True, nullable=False)
    status = db.Column(db.String(20), default='active', nullable=False)
    is_spectator = db.Column(db.Boolean, default=False)

class Comment(db.Model):
    __tablename__ = 'comments'

    id = db.Column(db.Integer, primary_key=True)
    content = db.Column(db.Text, nullable=False)
    posted_at = db.Column(db.DateTime, default=datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    event_id = db.Column(db.Integer, db.ForeignKey('events.id'), nullable=False)

class SearchEvent(db.Model):
    __tablename__ = 'search_events'

    id = db.Column(db.Integer, primary_key=True)
    game = db.Column(db.String(100), nullable=False)
    location = db.Column(db.String(100), nullable=False)
    participants = db.Column(db.Integer)
    price = db.Column(db.Float)
    date_time = db.Column(db.DateTime, nullable=False)
    event_type = db.Column(db.String(100), nullable=False)

    def __repr__(self):
        return f"<SearchEvent {self.id}: {self.game}>"

class ContactMessage(db.Model):
    __tablename__ = 'contact_messages'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), nullable=False)
    message = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f'<ContactMessage {self.name}>'
