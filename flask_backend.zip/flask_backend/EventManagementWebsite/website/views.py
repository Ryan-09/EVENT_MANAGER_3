from flask import Blueprint, render_template, url_for, request, flash, redirect, current_app
from flask_jwt_extended import jwt_required, get_jwt_identity
from flask_login import current_user, login_required, login_manager
from .forms import RegisterForm, LoginForm, UpdateProfileForm, ContactForm
from .models import SearchEvent, Event, ContactMessage, User, Booking, Comment
from datetime import datetime
from werkzeug.utils import secure_filename
from flask_jwt_extended import JWTManager
from . import db
from flask_restful import Api, Resource
import uuid
import jwt
from .models import User 
from datetime import datetime, timedelta
from flask import abort
from werkzeug.security import generate_password_hash, check_password_hash
from flask import jsonify
import os
from flask_login import login_user
from flask_cors import CORS


main_bp = Blueprint('main', __name__)
api=Api(main_bp)
CORS(main_bp, resources={r"/api/*": {"origins": "*"}})
secret_key = os.environ.get('SECRET_KEY', 'your_secret_key') 



def get_user_from_db(user_id):
    try:
        user = User.query.get(user_id)  # SQLAlchemy query to fetch the user by ID
        if user:
            return {
                'id': user.id,
                'email': user.email,
                'first_name': user.first_name,
                'surname': user.surname,
                'contact_number': user.contact_number,
                'street_address': user.street_address,
            }
        return None  # Return None if user is not found
    except Exception as e:
        print(f"Error fetching user from DB: {str(e)}")
        return None


@main_bp.route('/', methods=['GET', 'POST'])
def index():
    games = [game[0] for game in Event.query.with_entities(Event.game)
            .distinct().order_by(Event.game).all()]
    locations = [location[0] for location in Event.query.with_entities(Event.location)
                .distinct().order_by(Event.location).all()]
    
    search_performed = False
    results = []
    popular_events = []
    
    contact_form = ContactForm()
    
    if request.method == 'POST':
         if 'message' in request.form:
            if contact_form.validate_on_submit():
                contact_message = ContactMessage(
                    name=contact_form.name.data,
                    email=contact_form.email.data,
                    message=contact_form.message.data
                )
                try:
                    db.session.add(contact_message)
                    db.session.commit()
                    flash('Thank you for your message! We will get back to you soon.', 'success')
                    contact_form.name.data = ''
                    contact_form.email.data = ''
                    contact_form.message.data = ''
                except Exception as e:
                    db.session.rollback()
                    flash('An error occurred while sending your message. Please try again.', 'danger')
            else:
                for field, errors in contact_form.errors.items():
                    for error in errors:
                        flash(f'{field.title()}: {error}', 'error')
    else:
            game_search = request.form.get('game', '')
            location_search = request.form.get('location', '')
            
            query = Event.query.filter(Event.status.in_(['Open', 'Sold Out']))

            if game_search:
                query = query.filter(Event.game == game_search)
            if location_search:
                query = query.filter(Event.location == location_search)

            search_performed = True
            results = query.order_by(Event.date_time.asc()).all()
    
    if not search_performed or not results:
        query = Event.query.filter(
            Event.status.in_(['Open', 'Sold Out'])
        )
        popular_events = query.order_by(Event.participants.desc()).all()
    
    register_form = RegisterForm()
    login_form = LoginForm()
    
    return render_template('index.html',
                         login_form=login_form,
                         register_form=register_form,
                         popular_events=popular_events,
                         results=results,
                         games=games,
                         locations=locations,
                         search_performed=search_performed,
                         form=contact_form)

@main_bp.route('/create-event', methods=['GET', 'POST'])
@login_required
def create_event():
    if request.method == 'POST':
        game = request.form['gameTitle']
        event_type = request.form['eventType']
        description = request.form['eventDescription']
        location = request.form['eventLocation']
        date_time_str = f"{request.form['eventDate']} {request.form['eventTime']}"
        date_time = datetime.strptime(date_time_str, '%Y-%m-%d %H:%M')
        participants = int(request.form.get('participants', 0))
        max_participants = int(request.form.get('max_participants', 1))
        spectators = int(request.form.get('spectators', 0))
        max_spectators = int(request.form.get('max_spectators', 0))
        ticket_price = float(request.form['ticketPrice'])

        image_url = None

        if 'eventImage' in request.files:
            image_file = request.files['eventImage']
            if image_file and image_file.filename != '':
                filename = secure_filename(image_file.filename)
                
                target_directory = os.path.join(current_app.root_path, 'static/img')
                os.makedirs(target_directory, exist_ok=True) 
                image_path = os.path.join(target_directory, filename)
                
                try:
                    image_file.save(image_path)
                    image_url = f'img/{filename}'  
                except Exception as e:
                    flash(f'Error saving file: {str(e)}', 'error')

        new_event = Event(
            game=game,
            event_type=event_type,
            description=description,
            location=location,
            date_time=date_time,
            created_by_user_id=current_user.id,
            status='Open',
            ticket_price=ticket_price,
            max_participants=max_participants,
            participants=0,
            max_spectators=max_spectators,
            spectators=0,
            image_url=image_url
        )
        new_event.update_status()

        try:
            db.session.add(new_event)
            db.session.commit()
            flash('Event created successfully!', 'success')
        except Exception as e:
            db.session.rollback()
            flash(f'Error saving event: {str(e)}', 'error')

        return redirect(url_for('main.index'))

    return render_template('event_creation.html')

@main_bp.route('/event/<int:event_id>', methods=['GET'])
def event_details(event_id):
    event = Event.query.get_or_404(event_id)
    comments = Comment.query.filter_by(event_id=event_id)\
        .order_by(Comment.posted_at.desc())\
        .all()
    
    return render_template('event_details.html', 
                         event=event, 
                         comments=comments)

@main_bp.route('/event/<int:event_id>/comment', methods=['POST'])
@login_required
def add_comment(event_id):
    """Add a comment to an event"""
    event = Event.query.get_or_404(event_id)
    content = request.form.get('content')
    
    if not content:
        flash('Comment cannot be empty', 'error')
        return redirect(url_for('main.event_details', event_id=event_id))
    
    comment = Comment(
        content=content,
        user_id=current_user.id,
        event_id=event_id
    )
    
    try:
        db.session.add(comment)
        db.session.commit()
        flash('Comment added successfully!', 'success')
    except Exception as e:
        db.session.rollback()
        flash('An error occurred while adding your comment.', 'error')
    
    return redirect(url_for('main.event_details', event_id=event_id))

@main_bp.route('/event/<int:event_id>/book', methods=['POST'])
@login_required
def book_event(event_id):
    event = Event.query.get_or_404(event_id)
    
    booking_option = request.form.get('booking_option', '')
    
    try:
        ticket_type, quantity_str = booking_option.split('-')
        quantity = int(quantity_str)
        is_spectator = (ticket_type == 'spectator')
    except (ValueError, AttributeError):
        flash('Invalid booking option selected.', 'error')
        return redirect(url_for('main.event_details', event_id=event_id))
    
    if quantity < 1 or quantity > 4:
        flash('Please select between 1 and 4 tickets.', 'error')
        return redirect(url_for('main.event_details', event_id=event_id))
    
    if event.date_time < datetime.utcnow():
        flash('This event has already taken place.', 'error')
        return redirect(url_for('main.event_details', event_id=event_id))
    
    if event.status == 'Cancelled':
        flash('This event has been cancelled.', 'error')
        return redirect(url_for('main.event_details', event_id=event_id))
    
    if is_spectator:
        if event.spectators + quantity > event.max_spectators:
            flash(f'Not enough spectator tickets available. Only {event.max_spectators - event.spectators} tickets left.', 'error')
            return redirect(url_for('main.event_details', event_id=event_id))
    else:
        if event.participants + quantity > event.max_participants:
            flash(f'Not enough participant tickets available. Only {event.max_participants - event.participants} tickets left.', 'error')
            return redirect(url_for('main.event_details', event_id=event_id))
    
    total_price = event.ticket_price * quantity if not is_spectator else 0
    
    try:
        order_id = str(uuid.uuid4().hex[:20])
        
        booking = Booking(
            quantity=quantity,
            price=total_price,
            event_id=event_id,
            user_id=current_user.id,
            order_id=order_id,
            booking_date=datetime.utcnow(),
            is_spectator=is_spectator
        )
        
        if is_spectator:
            event.spectators += quantity
        else:
            event.participants += quantity
        
        event.update_status()
        
        db.session.add(booking)
        db.session.commit()
        
        ticket_type = "spectator" if is_spectator else "participant"
        if is_spectator:
            flash(f'Successfully booked {quantity} {ticket_type} ticket(s)!', 'success')
        else:
            flash(f'Successfully booked {quantity} {ticket_type} ticket(s) for ${total_price:.2f}!', 'success')
            
    except Exception as e:
        db.session.rollback()
        flash('An error occurred while processing your booking.', 'error')
    
    return redirect(url_for('main.event_details', event_id=event_id))

@main_bp.route('/user/<int:user_id>', methods=['GET', 'POST'])
@login_required
def profile_view():
    auth = request.authorization
    if not auth or not auth.username or not auth.password:
        return jsonify({"error": "Authentication required"}), 401

    user = User.query.filter_by(email=auth.username).first()
    if not user or not user.check_password(auth.password):  
        return jsonify({"error": "Invalid credentials"}), 403

    return jsonify({"user": {"id": user.id, "email": user.email, "name": user.first_name}})

@main_bp.route('/edit-event/<int:event_id>', methods=['GET', 'POST'])
@login_required
def edit_event(event_id):
    event = Event.query.get_or_404(event_id)
    
    if event.created_by_user_id != current_user.id:
        flash('You can only edit your own events.', 'error')
        return redirect(url_for('main.index'))
    
    if request.method == 'POST':
        event.game = request.form['gameTitle']
        event.event_type = request.form['eventType']
        event.description = request.form['eventDescription']
        event.location = request.form['eventLocation']
        
        date_time_str = f"{request.form['eventDate']} {request.form['eventTime']}"
        event.date_time = datetime.strptime(date_time_str, '%Y-%m-%d %H:%M')
        
        event.max_participants = int(request.form.get('max_participants', 0))
        event.spectators = int(request.form.get('spectators', 0))
        
        ticket_price = float(request.form['ticketPrice'])
        if ticket_price < 0:
            flash('Ticket price cannot be negative', 'error')
            return redirect(url_for('main.edit_event', event_id=event_id))
        event.ticket_price = ticket_price
        
        try:
            db.session.commit()
            flash('Event updated successfully!', 'success')
            return redirect(url_for('main.user_detail', user_id=current_user.id))
        except Exception as e:
            db.session.rollback()
            flash('An error occurred while updating the event.', 'error')
            return redirect(url_for('main.edit_event', event_id=event_id))
    
    event_date = event.date_time.strftime('%Y-%m-%d')
    event_time = event.date_time.strftime('%H:%M')
    
    return render_template('edit_event.html', event=event, 
                         event_date=event_date, event_time=event_time)

@main_bp.route('/event/<int:event_id>/cancel', methods=['POST'])
@login_required
def cancel_event(event_id):
    event = Event.query.get_or_404(event_id)

    if event.created_by_user_id != current_user.id:
        flash('You can only cancel your own events.', 'error')
        return redirect(url_for('main.event_details', event_id=event_id))

    event.status = 'Cancelled'
    db.session.commit()
    flash('Event cancelled successfully!', 'success')

    return redirect(url_for('main.user_detail', user_id=current_user.id))

@main_bp.route('/delete-event/<int:event_id>', methods=['POST'])
@login_required
def delete_event(event_id):
    event = Event.query.get_or_404(event_id)
    
    if event.created_by_user_id != current_user.id:
        flash("You are not authorised to delete this event.", "error")
        return redirect(url_for('main.user_detail', user_id=current_user.id))
    
    if event.status in ['Inactive', 'Cancelled']:
        db.session.delete(event)
        db.session.commit()
        flash("Event deleted successfully.", "success")
    else:
        flash("Only Inactive or Cancelled events can be deleted.", "error")
    
    return redirect(url_for('main.user_detail', user_id=current_user.id))


# ---------- Helper Functions ----------
def abort_if_event_not_found(event_id):
    event = Event.query.get(event_id)
    if not event:
        abort(404, message=f"Event {event_id} not found")
    return event

def abort_if_user_not_found(user_id):
    user = User.query.get(user_id)
    if not user:
        abort(404, message=f"User {user_id} not found")
    return user

# ---------- Resources ----------
from flask import request, jsonify, abort
from flask_restful import Resource
from werkzeug.security import generate_password_hash
from werkzeug.exceptions import BadRequest
from .models import User, Event, Booking  
from . import db  
import uuid
from datetime import datetime


from flask import request, jsonify, abort
from flask_restful import Resource
from werkzeug.security import generate_password_hash
from .models import User, Event, Booking 
from . import db  
import uuid
from datetime import datetime
from flask import redirect, url_for

# ---------- Resources ----------
import logging
import traceback

logger = logging.getLogger(__name__)

class Login(Resource):
    def post(self):
        try:
            data = request.get_json()
            first_name = data.get("first_name")
            password = data.get("password")

            if not first_name or not password:
                return {'error': 'Username and password are required'}, 400

            user = User.query.filter_by(first_name=first_name).first()
            if not user or not check_password_hash(user.password_hash, password):
                return {'error': 'Invalid username or password'}, 401

            expiration = datetime.utcnow() + timedelta(hours=1)
            token = jwt.encode(
                {'user_id': str(user.id), 'exp': expiration},
                current_app.config['SECRET_KEY'],
                algorithm='HS256'
            )

            logger.debug(f"Login successful for user {user.id}")

            return jsonify({
                'token': token,
                'user_id': str(user.id),
                'email': user.email,
                'first_name': user.first_name
            })
        except Exception as e:
            logger.error("Login error: %s", str(e))
            return {'error': 'Internal server error'}, 500
class Signup(Resource):
    def post(self):
        try:
            logger.info("Received signup request")
            data = request.get_json()
            
            
            logger.debug(f"Received data: {data}")
            
            if not data:
                logger.warning("No JSON data in request")
                return {'message': 'No data provided', 'error': 'missing_data'}, 400
                
            required_fields = ['first_name', 'surname', 'email', 'password', 'contact_number', 'street_address']
            missing_fields = [field for field in required_fields if field not in data or not data[field]]
            
            if missing_fields:
                logger.warning(f"Missing required fields: {missing_fields}")
                return {
                    'message': f'Missing required fields: {", ".join(missing_fields)}',
                    'error': 'missing_fields',
                    'missing': missing_fields
                }, 400

            if '@' not in data['email']:
                logger.warning(f"Invalid email format: {data['email']}")
                return {'message': 'Invalid email format', 'error': 'invalid_email'}, 400
                
            existing_user = User.query.filter_by(email=data['email']).first()
            if existing_user:
                logger.warning(f"Email already exists: {data['email']}")
                return {'message': 'Email is already in use', 'error': 'email_exists'}, 409

            try:
                logger.info("Creating new user")
                new_user = User(
                    first_name=data['first_name'],
                    surname=data['surname'],
                    email=data['email'],
                    contact_number=data['contact_number'],
                    street_address=data['street_address'],
                    is_admin=False
                )
                
                if len(data['password']) < 6:
                    logger.warning("Password too short")
                    return {'message': 'Password must be at least 6 characters long', 'error': 'password_too_short'}, 400
                    
                try:
                    new_user.set_password(data['password'])
                except AttributeError:
                    logger.error("set_password method missing from User model")
                    return {'message': 'User model error: set_password method missing', 'error': 'model_error'}, 500
                
                logger.info("Adding user to database")
                db.session.add(new_user)
                db.session.commit()
                
                logger.info(f"User created successfully with ID: {new_user.id}")
                return {'message': 'User created successfully', 'user_id': new_user.id}, 201
                
            except AttributeError as e:
                db.session.rollback()
                error_message = str(e)
                logger.error(f"AttributeError: {error_message}")
                logger.error(traceback.format_exc())
                return {'message': f'User model error: {error_message}', 'error': 'attribute_error'}, 500
                
            except Exception as e:
                db.session.rollback()
                error_message = str(e)
                logger.error(f"Database error: {error_message}")
                logger.error(traceback.format_exc())
                return {'message': f'Database error: {error_message}', 'error': 'database_error'}, 500
                
        except Exception as e:
            error_message = str(e)
            logger.error(f"General error: {error_message}")
            logger.error(traceback.format_exc())
            return {'message': f'An unexpected error occurred: {error_message}', 'error': 'general_error'}, 500


class Events(Resource):
    def get(self):
        events = Event.query.all()
        return {
            'events': [
                {
                    'id': e.id,
                    'game': e.game,
                    'event_type': e.event_type,
                    'description': e.description,
                    'location': e.location,
                    'date_time': e.date_time.isoformat(),
                    'status': e.status,
                    'ticket_price': e.ticket_price,
                    'max_participants': e.max_participants,
                    'participants': e.participants,
                    'max_spectators': e.max_spectators,
                    'spectators': e.spectators,
                    'image_url': e.image_url
                } for e in events
            ]
        }, 200

class CreateEvent(Resource):
    def post(self):
        print("Received POST request to /api/create-event")
        data = request.get_json()
        print("Parsed JSON data:", data)

        try:
            user_id = data.get('user_id')
            if not user_id:
                user_id = 1 

            print("Attempting to create Event object...")

            new_event = Event(
                game=data['game_title'],
                event_type=data['event_name'],
                description=data['description'],
                location=data['location'],
                date_time=datetime.fromisoformat(data['event_date']),
                created_by_user_id=user_id,
                status='Open',
                ticket_price=float(data.get('ticket_price', 0)),
                max_participants=int(data.get('max_participants', 0)),
                participants=0,
                max_spectators=int(data.get('max_spectators', 0)),
                spectators=0,
                image_url=data.get('image_url')
            )

            print("Event object created:", new_event)

            db.session.add(new_event)
            db.session.commit()
            print("Event committed to database successfully.")

            return {'message': 'Event created successfully', 'event_id': new_event.id}, 201

        except Exception as e:
            db.session.rollback()
            print("Exception occurred during event creation:")
            print(traceback.format_exc()) 
            return {'message': f'An error occurred: {str(e)}'}, 500

        
class BookEvent(Resource):
    def post(self, event_id):
        data = request.get_json()
        event = Event.query.get(event_id)

        if not event:
            return {'message': 'Event not found'}, 404

        try:
            ticket_type = data['ticket_type']
            quantity = data['quantity']
            user_id = data.get('user_id', 1)  
            is_spectator = (ticket_type == 'spectator')

            if quantity < 1 or quantity > 4:
                return {'message': 'Please select between 1 and 4 tickets'}, 400

            if event.date_time < datetime.utcnow():
                return {'message': 'This event has already taken place'}, 400

            if event.status == 'Cancelled':
                return {'message': 'This event has been cancelled'}, 400

            if is_spectator:
                if event.spectators + quantity > event.max_spectators:
                    return {'message': 'Not enough spectator tickets available'}, 400
            else:
                if event.participants + quantity > event.max_participants:
                    return {'message': 'Not enough participant tickets available'}, 400

            total_price = event.ticket_price * quantity if not is_spectator else 0
            order_id = uuid.uuid4().hex[:20]

            booking = Booking(
                quantity=quantity,
                price=total_price,
                event_id=event_id,
                user_id=user_id,
                order_id=order_id,
                booking_date=datetime.utcnow(),
                is_spectator=is_spectator
            )

            if is_spectator:
                event.spectators += quantity
            else:
                event.participants += quantity

            event.update_status()
            db.session.add(booking)
            db.session.commit()

            return {'message': 'Booking successful', 'order_id': order_id}, 201
        except Exception as e:
            db.session.rollback()
            return {'message': f'An error occurred: {str(e)}'}, 500

class UserProfile(Resource):
    @jwt_required()
    def get(self, user_id):
        try:
            current_user_id = str(get_jwt_identity())

            if current_user_id != str(user_id):
                return {'message': 'Unauthorized access'}, 403

            user = User.query.get(user_id)
            if not user:
                return {'message': 'User not found'}, 404

            return {
                'user_id': user.id,
                'email': user.email,
                'first_name': user.first_name,
                'surname': user.surname,
                'contact_number': user.contact_number,
                'street_address': user.street_address
            }, 200
        except Exception as e:
            current_app.logger.error(f"Error in UserProfile: {str(e)}")
            return {'message': 'Internal server error'}, 500
        # ---------- Routes ----------
api.add_resource(Login, '/api/login')
api.add_resource(Signup, '/api/signup')
api.add_resource(Events, '/api/events')
api.add_resource(CreateEvent, '/api/create-event')
api.add_resource(BookEvent, '/api/event/<int:event_id>/book')
api.add_resource(UserProfile, '/api/user/<int:user_id>')
