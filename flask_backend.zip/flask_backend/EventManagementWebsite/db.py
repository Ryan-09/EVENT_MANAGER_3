from website import create_app, db
from website.models import User, Event 
from flask_jwt_extended import JWTManager

app = create_app()

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///site.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

app.config['SECRET_KEY'] = 'your_secret'  
app.config['JWT_SECRET_KEY'] = 'your-jwt-secret'  

app.config['JWT_TOKEN_LOCATION'] = ['headers', 'cookies']  
app.config['JWT_HEADER_NAME'] = 'Authorization'   
app.config['JWT_HEADER_TYPE'] = 'Bearer'
print("App Config: ", app.config)

jwt = JWTManager(app)

with app.app_context():
    db.create_all()

